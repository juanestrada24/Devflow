# Funciones reutilizables de cálculo (ROI, Upside, etc.)
